import { redirect } from 'next/navigation';

export default function MobilePage() {
  redirect('/m/driver');
}
