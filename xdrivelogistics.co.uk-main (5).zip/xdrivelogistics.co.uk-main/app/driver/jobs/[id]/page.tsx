'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { getJobClientFields } from '../../../../lib/jobClientFields';
import { supabase, isSupabaseConfigured } from '../../../../lib/supabaseClient';
import type { DbJob } from '../../../../lib/types/database';
import ProtectedRoute from '../../../components/ProtectedRoute';
import { useAuth } from '../../../components/AuthContext';
import { getLoadDetailSections } from '../../../../lib/loadPostingDetails';

const STATUS_LABEL: Record<string, string> = {
  draft: 'Received',
  posted: 'Posted',
  quoted: 'Quoted',
  awarded: 'Awarded',
  allocated: 'Allocated',
  on_my_way: 'On My Way',
  on_site_pickup: 'At Pickup',
  loaded: 'Loaded',
  on_site_delivery: 'At Delivery',
  collected: 'Collected',
  in_transit: 'In Transit',
  delivered: 'Delivered',
  completed: 'Completed',
  invoiced: 'Invoiced',
  paid: 'Paid',
  cancelled: 'Cancelled',
  disputed: 'Disputed',
  // milestone events (stored in status_history only)
  driver_en_route: 'En Route to Pickup',
  arrived_pickup: 'Arrived at Pickup',
  arrived_delivery: 'Arrived at Delivery',
};

function buildMapsUrl(app: 'google' | 'waze' | 'apple', address: string, postcode?: string | null): string {
  const q = encodeURIComponent(postcode ? `${address}, ${postcode}` : address);
  if (app === 'google') return `https://www.google.com/maps/dir/?api=1&destination=${q}`;
  if (app === 'waze')   return `https://waze.com/ul?q=${q}&navigate=yes`;
  return `maps://maps.apple.com/?daddr=${q}`;
}

/** Validate that a URL uses a safe scheme before rendering it in an img src. */
function sanitizePhotoUrl(url: string | null): string | null {
  if (!url) return null;

  // Strictly allow only base64-encoded image data URLs.
  if (/^data:/i.test(url)) {
    return /^data:image\/(?:png|jpe?g|webp|gif);base64,[a-z0-9+/=]+$/i.test(url) ? url : null;
  }

  // Allow only browser-generated blob URLs (blob:http[s]://...).
  if (/^blob:/i.test(url)) {
    return /^blob:https?:\/\/[^\s]+$/i.test(url) ? url : null;
  }

  try {
    const parsed = new URL(url);

    // Only allow standard web protocols from expected storage hosts.
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return null;
    const host = parsed.hostname.toLowerCase();
    if (host === 'supabase.co' || host.endsWith('.supabase.co')) {
      return parsed.toString();
    }
  } catch {
    return null;
  }

  return null;
}

export default function DriverJobDetailPage() {
  const router = useRouter();
  const { user } = useAuth();
  const params = useParams<{ id: string }>();
  const jobId = params?.id ?? '';
  const companyId = user?.companyId ?? null;

  const [job, setJob] = useState<DbJob | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Driver notes
  const [driverNotes, setDriverNotes] = useState('');

  // Collection photo
  const [collectionPhotoPreview, setCollectionPhotoPreview] = useState<string | null>(null);
  const collectionInputRef = useRef<HTMLInputElement>(null);

  // Delivery photos (multiple)
  const [deliveryPhotoPreviews, setDeliveryPhotoPreviews] = useState<string[]>([]);
  const deliveryInputRef = useRef<HTMLInputElement>(null);

  // Signature
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [sigClientName, setSigClientName] = useState('');
  const [isSigning, setIsSigning] = useState(false);

  const [driverId, setDriverId] = useState('');
  const normalizedDriverId = driverId.trim();
  // Track which milestone events have been recorded for this job session
  const [milestones, setMilestones] = useState<Set<string>>(new Set());

  const loadJob = useCallback(async () => {
    if (!jobId || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    if (!normalizedDriverId) {
      setError('Driver session not ready. Please wait and refresh.');
      setLoading(false);
      return;
    }
    const { data, error: dbError } = await supabase
      .from('jobs')
      .select('*')
      .eq('id', jobId)
      .eq('assigned_driver_id', normalizedDriverId)
      .maybeSingle();

    if (dbError || !data) {
      setError('Job not found.');
    } else {
      setJob(data as DbJob);
      setDriverNotes(data.driver_notes ?? '');
      setCollectionPhotoPreview(data.collection_photo_url ?? null);
      setDeliveryPhotoPreviews(data.delivery_photos ?? []);
      setSigClientName(data.client_signature_name ?? '');
      // Restore milestones already recorded in status_history
      const history = Array.isArray(data.status_history) ? data.status_history : [];
      setMilestones(new Set(history.map((e: { status: string }) => e.status)));
    }
    setLoading(false);
  }, [jobId, normalizedDriverId]);

  useEffect(() => {
    if (!user?.driverId || typeof user.driverId !== 'string') return;
    setDriverId(user.driverId.trim());
  }, [user?.driverId]);

  useEffect(() => {
    if (!normalizedDriverId) return;
    loadJob();
  }, [normalizedDriverId, loadJob]);

  // ── Canvas signature helpers ─────────────────────────────────
  const startSig = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setIsSigning(true);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    ctx.beginPath();
    ctx.moveTo(clientX - rect.left, clientY - rect.top);
  };

  const drawSig = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isSigning) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#0A2239';
    ctx.lineTo(clientX - rect.left, clientY - rect.top);
    ctx.stroke();
  };

  const endSig = () => setIsSigning(false);

  const clearSig = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx?.clearRect(0, 0, canvas.width, canvas.height);
  };

  const getSignatureDataUrl = () => canvasRef.current?.toDataURL('image/png') ?? null;

  // ── Photo helpers ────────────────────────────────────────────
  const uploadPhotoToStorage = async (file: File, prefix: string): Promise<string> => {
    if (!companyId || !jobId) {
      // Fallback: return base64 if storage path is unavailable
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    }
    const ext = file.name.split('.').pop() ?? 'jpg';
    const path = `${companyId}/${jobId}/${prefix}-${Date.now()}.${ext}`;
    const { error: uploadError } = await supabase.storage
      .from('pod-photos')
      .upload(path, file, { upsert: true });
    if (uploadError) {
      // Fallback to base64 if storage upload fails
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    }
    const { data: signedData } = await supabase.storage
      .from('pod-photos')
      .createSignedUrl(path, 60 * 60 * 24 * 365); // 1-year signed URL
    return signedData?.signedUrl ?? path;
  };

  const handleRemoveCollectionPhoto = () => {
    setCollectionPhotoPreview(null);
    if (collectionInputRef.current) collectionInputRef.current.value = '';
  };

  const handleCollectionPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await uploadPhotoToStorage(file, 'collection');
    setCollectionPhotoPreview(url);
  };

  const handleDeliveryPhotos = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    const urls = await Promise.all(files.map((f, i) => uploadPhotoToStorage(f, `delivery-${i}`)));
    setDeliveryPhotoPreviews(prev => [...prev, ...urls]);
  };

  // ── Status transition helpers ────────────────────────────────
  const appendStatusHistory = (
    current: DbJob['status_history'],
    newStatus: string
  ) => {
    const history = Array.isArray(current) ? current : [];
    return [...history, { status: newStatus, timestamp: new Date().toISOString() }];
  };

  const updateJobStatus = async (newStatus: string, extraFields: Record<string, unknown> = {}) => {
    if (!job || !normalizedDriverId || !isSupabaseConfigured) return;
    setActionLoading(true);
    setError('');

    const body: Record<string, unknown> = {
      p_driver_id: normalizedDriverId,
      p_job_id: job.id,
      p_next_status: newStatus,
      p_driver_notes: driverNotes || null,
    };

    if (typeof extraFields.collection_photo_url === 'string') {
      body.p_collection_photo_url = extraFields.collection_photo_url;
    }
    if (Array.isArray(extraFields.delivery_photos)) {
      body.p_delivery_photos = extraFields.delivery_photos;
    }
    if (typeof extraFields.delivery_signature_data === 'string') {
      body.p_delivery_signature_data = extraFields.delivery_signature_data;
    }
    if (typeof extraFields.client_signature_name === 'string') {
      body.p_client_signature_name = extraFields.client_signature_name;
    }

    const { error: dbError } = await supabase.rpc('driver_update_job_status_atomic', body);

    if (dbError) {
      setError(dbError.message);
    } else {
      setSuccessMsg(`Job marked as ${STATUS_LABEL[newStatus] ?? newStatus}`);
      await loadJob();
      setTimeout(() => setSuccessMsg(''), 3000);
    }
    setActionLoading(false);
  };

  // Record a milestone event in status_history WITHOUT changing jobs.status
  const recordMilestone = async (event: string) => {
    if (!job || !normalizedDriverId || !isSupabaseConfigured || milestones.has(event)) return;
    setActionLoading(true);
    setError('');
    const newHistory = appendStatusHistory(job.status_history, event);
    const { error: dbError } = await supabase
      .from('jobs')
      .update({ status_history: newHistory })
      .eq('id', job.id)
      .eq('assigned_driver_id', normalizedDriverId);
    if (dbError) {
      setError(dbError.message);
    } else {
      setMilestones(prev => new Set<string>([...prev, event]));
      setSuccessMsg(`✅ ${STATUS_LABEL[event] ?? event} recorded`);
      await loadJob();
      setTimeout(() => setSuccessMsg(''), 3000);
    }
    setActionLoading(false);
  };

  const handleCollect = () =>
  {
    updateJobStatus('on_my_way');
  };

  const handleArrivePickup = () => updateJobStatus('on_site_pickup');

  const handleLoad = () =>
  {
    const collectionPhoto = collectionPhotoPreview ?? job?.collection_photo_url ?? null;
    if (!collectionPhoto) {
      setError('Loading photo is required before marking the job as loaded.');
      return;
    }
    updateJobStatus('loaded', {
      collection_photo_url: collectionPhoto,
    });
  };

  const handleStartTransit = () => {
    updateJobStatus('on_site_delivery');
  };

  const handleDeliver = () => {
    const sigData = getSignatureDataUrl();
    if (!deliveryPhotoPreviews.length) {
      setError('At least one delivery photo is required before marking as delivered.');
      return;
    }
    if (!sigData) {
      setError('Recipient signature is required before marking as delivered.');
      return;
    }
    if (!sigClientName.trim()) {
      setError('Recipient name is required before marking as delivered.');
      return;
    }
    updateJobStatus('delivered', {
      delivery_photos: deliveryPhotoPreviews,
      delivery_signature_data: sigData,
      client_signature_name: sigClientName.trim(),
    });
  };

  // ── Render ───────────────────────────────────────────────────
  if (loading) {
    return (
      <div style={{ padding: '3rem', textAlign: 'center', color: '#6b7280' }}>
        Loading job…
      </div>
    );
  }

  if (!job) {
    return (
      <div style={{ padding: '2rem', textAlign: 'center', color: '#dc2626' }}>
        {error || 'Job not found.'}
      </div>
    );
  }

  const currentStatus = job.current_status ?? job.status;
  const canCollect = currentStatus === 'allocated';
  const canArrivePickup = currentStatus === 'on_my_way';
  const canLoad = currentStatus === 'on_site_pickup';
  const canStartTransit = currentStatus === 'loaded';
  const canDeliver = currentStatus === 'on_site_delivery';
  const clientFields = getJobClientFields(job);
  const hasEnRoute = milestones.has('driver_en_route');
  const hasArrivedPickup = milestones.has('arrived_pickup');
  const hasArrivedDelivery = milestones.has('arrived_delivery');
  const loadDetailSections = getLoadDetailSections(job);

  return (
    <ProtectedRoute allowedRoles={['driver']}>
    <div style={{ minHeight: '100dvh', backgroundColor: '#f3f4f6', paddingBottom: '5rem' }}>
      {/* Header */}
      <header
        style={{
          backgroundColor: '#0A2239',
          padding: '1rem 1.25rem',
          display: 'flex',
          alignItems: 'center',
          gap: '0.75rem',
          position: 'sticky',
          top: 0,
          zIndex: 10,
        }}
      >
        <button
          onClick={() => router.push('/driver/jobs')}
          style={{ background: 'none', border: 'none', color: '#93c5fd', fontSize: '1.4rem', cursor: 'pointer', padding: 0 }}
        >
          ←
        </button>
        <div>
          <p style={{ color: '#93c5fd', fontSize: '0.7rem', margin: 0 }}>Job Detail</p>
          <h1 style={{ color: '#ffffff', fontSize: '1rem', fontWeight: '700', margin: 0 }}>
            #{job.id.slice(0, 8).toUpperCase()}
          </h1>
        </div>
        <span
          style={{
            marginLeft: 'auto',
            fontSize: '0.7rem',
            fontWeight: '700',
            color: '#ffffff',
            backgroundColor: '#1e4d7b',
            padding: '0.25rem 0.65rem',
            borderRadius: '20px',
          }}
        >
          {STATUS_LABEL[currentStatus] ?? currentStatus}
        </span>
      </header>

      <div style={{ padding: '1rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        {/* Alerts */}
        {error && (
          <div style={{ backgroundColor: '#fef2f2', border: '1px solid #fca5a5', borderRadius: '8px', padding: '0.75rem', color: '#dc2626', fontSize: '0.875rem' }}>
            {error}
          </div>
        )}
        {successMsg && (
          <div style={{ backgroundColor: '#f0fdf4', border: '1px solid #86efac', borderRadius: '8px', padding: '0.75rem', color: '#15803d', fontSize: '0.875rem' }}>
            {successMsg}
          </div>
        )}

        {/* Route card */}
        <Section title="Route">
          <InfoRow icon="📦" label="Collection" value={job.pickup_location ?? 'TBC'} />
          {job.pickup_datetime && (
            <InfoRow icon="🕐" label="Pickup time" value={new Date(job.pickup_datetime).toLocaleString('en-GB')} />
          )}
          {/* Navigate to pickup */}
          {job.pickup_location && (
            <NavButtons address={job.pickup_location} postcode={job.pickup_postcode} label="Pickup" />
          )}
          <div style={{ borderTop: '1px dashed #e5e7eb', margin: '0.5rem 0' }} />
          <InfoRow icon="📍" label="Delivery" value={job.delivery_location ?? 'TBC'} />
          {job.delivery_datetime && (
            <InfoRow icon="🕐" label="Delivery time" value={new Date(job.delivery_datetime).toLocaleString('en-GB')} />
          )}
          {/* Navigate to delivery */}
          {job.delivery_location && (
            <NavButtons address={job.delivery_location} postcode={job.delivery_postcode} label="Delivery" />
          )}
          {/* Distance / duration */}
          {(job.job_distance_miles != null || job.job_distance_minutes != null) && (
            <div style={{ display: 'flex', gap: '1rem', marginTop: '0.5rem', fontSize: '0.82rem', color: '#6b7280' }}>
              {job.job_distance_miles != null && <span>📏 {job.job_distance_miles.toFixed(1)} mi</span>}
              {job.job_distance_minutes != null && <span>⏱ {Math.round(job.job_distance_minutes)} min</span>}
            </div>
          )}
        </Section>

        {/* Milestone buttons for allocated job */}
        {canCollect && (
          <Section title="Journey Milestones">
            <p style={{ fontSize: '0.82rem', color: '#6b7280', margin: '0 0 0.75rem' }}>
              Tap each milestone as you progress. These are visible to your dispatcher.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              <MilestoneButton
                label="🚗 En Route to Pickup"
                done={hasEnRoute}
                disabled={actionLoading}
                onTap={() => recordMilestone('driver_en_route')}
              />
              <MilestoneButton
                label="📍 Arrived at Pickup"
                done={hasArrivedPickup}
                disabled={actionLoading || !hasEnRoute}
                onTap={() => recordMilestone('arrived_pickup')}
              />
            </div>
          </Section>
        )}

        {/* Milestone button for in_transit job */}
        {canDeliver && (
          <Section title="Journey Milestones">
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              <MilestoneButton
                label="📍 Arrived at Delivery"
                done={hasArrivedDelivery}
                disabled={actionLoading}
                onTap={() => recordMilestone('arrived_delivery')}
              />
            </div>
          </Section>
        )}

        {/* Cargo */}
        <Section title="Cargo">
          <InfoRow icon="👤" label="Client" value={clientFields.name} />
          {clientFields.phone && <InfoRow icon="📞" label="Client phone" value={clientFields.phone} />}
          {clientFields.email && <InfoRow icon="✉️" label="Client email" value={clientFields.email} />}          {(job.requested_cargo_label || job.cargo_type) && <InfoRow icon="" label="Type" value={job.requested_cargo_label ?? job.cargo_type ?? ''} />}
          {(job.requested_vehicle_label || job.vehicle_type) && <InfoRow icon="" label="Vehicle" value={job.requested_vehicle_label ?? job.vehicle_type ?? ''} />}
          {clientFields.cargoNotes && (
            <InfoRow icon="⚠️" label="Special requirements" value={clientFields.cargoNotes} />
          )}
          {job.weight_kg != null && <InfoRow icon="⚖️" label="Weight" value={`${job.weight_kg} kg`} />}
        </Section>
        {loadDetailSections.length > 0 && (
          <Section title="Operational Details">
            <div style={{ display: 'grid', gap: '0.75rem' }}>
              {loadDetailSections.map((section) => (
                <div key={section.title}>
                  <div style={{ color: '#64748b', fontSize: '0.72rem', fontWeight: 800, textTransform: 'uppercase', marginBottom: '0.4rem' }}>{section.title}</div>
                  <div style={{ display: 'grid', gap: '0.45rem' }}>
                    {section.items.map((item) => (
                      <InfoRow key={`${section.title}-${item.label}`} icon="" label={item.label} value={item.value} />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Section>
        )}
        {/* Collection photo – shown until the trip starts */}
        {(canLoad || currentStatus === 'loaded') && (
          <Section title="Loading Photos & Message">
            <p style={{ fontSize: '0.85rem', color: '#6b7280', margin: '0 0 0.75rem' }}>
              Add loading images and a message before marking the job as loaded.
            </p>
            <input
              ref={collectionInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              style={{ display: 'none' }}
              onChange={handleCollectionPhoto}
            />
            {collectionPhotoPreview ? (
              <div>
                <img
                  src={sanitizePhotoUrl(collectionPhotoPreview) ?? undefined}
                  alt="Collection"
                  style={{ width: '100%', borderRadius: '8px', marginBottom: '0.5rem' }}
                />
                <button
                  onClick={handleRemoveCollectionPhoto}
                  style={ghostBtn}
                >
                  Remove photo
                </button>
              </div>
            ) : (
              <button onClick={() => collectionInputRef.current?.click()} style={photoBtn}>
                📷 Take / Upload Photo
              </button>
            )}
            <textarea
              value={driverNotes}
              onChange={e => setDriverNotes(e.target.value)}
              placeholder="Message about loading, goods condition, access, waiting time, or issue..."
              rows={3}
              style={{
                width: '100%',
                marginTop: '0.75rem',
                padding: '0.65rem 0.75rem',
                border: '1px solid #d1d5db',
                borderRadius: '8px',
                fontSize: '0.9rem',
                resize: 'vertical',
                boxSizing: 'border-box',
              }}
            />
          </Section>
        )}

        {/* Delivery photos + signature – shown when job is in_transit */}
        {canDeliver && (
          <>
            <Section title="Delivery Photos">
              <input
                ref={deliveryInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                multiple
                style={{ display: 'none' }}
                onChange={handleDeliveryPhotos}
              />
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '0.75rem' }}>
                {deliveryPhotoPreviews.map((src, i) => (
                  <img key={i} src={sanitizePhotoUrl(src) ?? undefined} alt={`Delivery ${i + 1}`} style={{ width: '80px', height: '80px', objectFit: 'cover', borderRadius: '6px' }} />
                ))}
              </div>
              <button onClick={() => deliveryInputRef.current?.click()} style={photoBtn}>
                📷 Add Photo
              </button>
            </Section>

            <Section title="Client Signature">
              <input
                type="text"
                placeholder="Recipient name"
                value={sigClientName}
                onChange={e => setSigClientName(e.target.value)}
                style={{ width: '100%', padding: '0.65rem 0.75rem', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '0.9rem', marginBottom: '0.75rem', boxSizing: 'border-box' }}
              />
              <canvas
                ref={canvasRef}
                width={320}
                height={130}
                onMouseDown={startSig}
                onMouseMove={drawSig}
                onMouseUp={endSig}
                onMouseLeave={endSig}
                onTouchStart={startSig}
                onTouchMove={drawSig}
                onTouchEnd={endSig}
                style={{
                  width: '100%',
                  height: '130px',
                  border: '1px solid #d1d5db',
                  borderRadius: '8px',
                  backgroundColor: '#fafafa',
                  touchAction: 'none',
                  cursor: 'crosshair',
                  display: 'block',
                }}
              />
              <button onClick={clearSig} style={{ ...ghostBtn, marginTop: '0.5rem' }}>
                Clear signature
              </button>
            </Section>
          </>
        )}

        {/* Driver notes */}
        <Section title="Driver Notes">
          <textarea
            value={driverNotes}
            onChange={e => setDriverNotes(e.target.value)}
            placeholder="Add notes about this job…"
            rows={3}
            style={{
              width: '100%',
              padding: '0.65rem 0.75rem',
              border: '1px solid #d1d5db',
              borderRadius: '8px',
              fontSize: '0.9rem',
              resize: 'vertical',
              boxSizing: 'border-box',
            }}
          />
        </Section>

        {/* Status history */}
        {Array.isArray(job.status_history) && job.status_history.length > 0 && (
          <Section title="Status History">
            <ol style={{ margin: 0, padding: '0 0 0 1.25rem', fontSize: '0.85rem', color: '#374151' }}>
              {job.status_history.map((entry, i) => (
                <li key={i} style={{ marginBottom: '0.3rem' }}>
                  <strong>{STATUS_LABEL[entry.status] ?? entry.status}</strong>{' '}
                  <span style={{ color: '#6b7280' }}>
                    — {new Date(entry.timestamp).toLocaleString('en-GB')}
                  </span>
                </li>
              ))}
            </ol>
          </Section>
        )}
      </div>

      {/* Action bar */}
      {(canCollect || canArrivePickup || canLoad || canStartTransit || canDeliver) && (
        <div
          style={{
            position: 'fixed',
            bottom: 0,
            left: '50%',
            transform: 'translateX(-50%)',
            width: '100%',
            maxWidth: '480px',
            padding: '1rem',
            backgroundColor: '#ffffff',
            borderTop: '1px solid #e5e7eb',
            boxShadow: '0 -2px 8px rgba(0,0,0,0.1)',
          }}
        >
          {canCollect && (
            <button
              onClick={handleCollect}
              disabled={actionLoading}
              style={actionBtn('#1d4ed8')}
            >
              {actionLoading ? 'Updating…' : '🚚 Confirm Collection'}
            </button>
          )}
          {canArrivePickup && (
            <button onClick={handleArrivePickup} disabled={actionLoading} style={actionBtn('#1d4ed8')}>
              {actionLoading ? 'Updating...' : 'Arrived Pickup'}
            </button>
          )}
          {canLoad && (
            <button onClick={handleLoad} disabled={actionLoading} style={actionBtn('#0f766e')}>
              {actionLoading ? 'Updating...' : 'Loaded'}
            </button>
          )}
          {canStartTransit && (
            <button
              onClick={handleStartTransit}
              disabled={actionLoading}
              style={actionBtn('#0f766e')}
            >
              {actionLoading ? 'Updating…' : '🛣️ Start Transit'}
            </button>
          )}
          {canDeliver && (
            <button
              onClick={handleDeliver}
              disabled={actionLoading}
              style={actionBtn('#15803d')}
            >
              {actionLoading ? 'Updating…' : '✅ Confirm Delivery'}
            </button>
          )}
        </div>
      )}
    </div>
    </ProtectedRoute>
  );
}

// ── Small helpers ──────────────────────────────────────────────

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div
      style={{
        backgroundColor: '#ffffff',
        borderRadius: '12px',
        border: '1px solid #e5e7eb',
        overflow: 'hidden',
      }}
    >
      <div style={{ padding: '0.6rem 1rem', backgroundColor: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>
        <span style={{ fontSize: '0.75rem', fontWeight: '700', color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          {title}
        </span>
      </div>
      <div style={{ padding: '0.85rem 1rem' }}>{children}</div>
    </div>
  );
}

function InfoRow({ icon, label, value }: { icon: string; label: string; value: string }) {
  return (
    <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.4rem', fontSize: '0.875rem' }}>
      <span>{icon}</span>
      <span style={{ color: '#6b7280', flexShrink: 0 }}>{label}:</span>
      <span style={{ color: '#1f2937', fontWeight: '500' }}>{value}</span>
    </div>
  );
}

function NavButtons({ address, postcode, label }: { address: string; postcode?: string | null; label: string }) {
  return (
    <div style={{ display: 'flex', gap: '0.4rem', marginTop: '0.4rem', marginBottom: '0.25rem', flexWrap: 'wrap' }}>
      <a
        href={buildMapsUrl('google', address, postcode)}
        target="_blank"
        rel="noopener noreferrer"
        style={navLinkStyle('#4285F4')}
      >
        🗺 Google Maps
      </a>
      <a
        href={buildMapsUrl('waze', address, postcode)}
        target="_blank"
        rel="noopener noreferrer"
        style={navLinkStyle('#33ccff')}
      >
        🚦 Waze
      </a>
      <a
        href={buildMapsUrl('apple', address, postcode)}
        target="_blank"
        rel="noopener noreferrer"
        style={navLinkStyle('#555')}
      >
        🍎 Apple Maps
      </a>
      <span style={{ fontSize: '0.7rem', color: '#9ca3af', alignSelf: 'center' }}>Navigate to {label}</span>
    </div>
  );
}

function MilestoneButton({ label, done, disabled, onTap }: {
  label: string;
  done: boolean;
  disabled: boolean;
  onTap: () => void;
}) {
  return (
    <button
      onClick={onTap}
      disabled={done || disabled}
      style={{
        width: '100%',
        padding: '0.7rem 1rem',
        borderRadius: '10px',
        border: done ? '1px solid #86efac' : '1px solid #d1d5db',
        backgroundColor: done ? '#f0fdf4' : disabled ? '#f3f4f6' : '#eff6ff',
        color: done ? '#15803d' : disabled ? '#9ca3af' : '#1d4ed8',
        fontSize: '0.9rem',
        fontWeight: '600',
        cursor: done || disabled ? 'default' : 'pointer',
        textAlign: 'left',
        display: 'flex',
        alignItems: 'center',
        gap: '0.5rem',
      }}
    >
      {done ? '✅' : '⬜'} {label}
      {done && <span style={{ marginLeft: 'auto', fontSize: '0.75rem', color: '#6b7280' }}>Recorded</span>}
    </button>
  );
}

const navLinkStyle = (color: string): React.CSSProperties => ({
  padding: '0.3rem 0.6rem',
  borderRadius: '6px',
  border: `1px solid ${color}22`,
  backgroundColor: `${color}11`,
  color,
  fontSize: '0.78rem',
  fontWeight: '600',
  textDecoration: 'none',
  display: 'inline-block',
});

const photoBtn: React.CSSProperties = {
  width: '100%',
  padding: '0.75rem',
  backgroundColor: '#eff6ff',
  color: '#1d4ed8',
  border: '1px dashed #93c5fd',
  borderRadius: '8px',
  fontSize: '0.9rem',
  fontWeight: '600',
  cursor: 'pointer',
};

const ghostBtn: React.CSSProperties = {
  background: 'none',
  border: 'none',
  color: '#6b7280',
  fontSize: '0.8rem',
  cursor: 'pointer',
  padding: 0,
  textDecoration: 'underline',
};

const actionBtn = (bg: string): React.CSSProperties => ({
  width: '100%',
  padding: '1rem',
  backgroundColor: bg,
  color: '#ffffff',
  border: 'none',
  borderRadius: '12px',
  fontSize: '1rem',
  fontWeight: '700',
  cursor: 'pointer',
});
